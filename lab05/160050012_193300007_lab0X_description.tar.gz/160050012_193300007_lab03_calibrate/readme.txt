*****Lab 5******

###### Division of Tasks

Contribution Respectively by roll numbers 160050012, 193300007

1.1 Focus! : 100, 35
1.2 Reproject : 100, 40
1.3 I wish I had that mobile phone! : 100, 45

##### Honour Code 

I pledge on my Gita that I have not given or received any unauthorized assistance on this assignment or any previous task.
- (160050012 , Piyush Onkar) , (193300007 , Ayush Pandey)


##### References 
1. Draw Markers : https://stackoverflow.com/questions/57872403/draw-multiple-markers-on-an-image-using-pixel-coordinates-opencv
2. Camera Calibration : https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_calib3d/py_calibration/py_calibration.html
