*****Lab 7******

###### Division of Tasks

2.1.1 Lifting

##### Honour Code 

I pledge on my Gita that I have not given or received any unauthorized assistance on this assignment or any previous task.
- (160050012 , Piyush Onkar)


##### References 
1. Pytorch Tutorials : https://pytorch.org/tutorials/
