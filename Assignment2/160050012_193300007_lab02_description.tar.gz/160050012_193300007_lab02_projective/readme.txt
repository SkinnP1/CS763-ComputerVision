*****Lab 2******

###### Division of Tasks

1.1 Affine Transformations : 100, 30
1.2 Perspective Transformations: 100, 40
2   Document Scanner: 100, 20

##### Honour Code 

I pledge on my Gita that I have not given or received any unauthorized assistance on this assignment or any previous task.
- (160050012 , Piyush Onkar) , (193300007 , Ayush Pandey)


##### References 
1. Affine Transformations : https://www.geeksforgeeks.org/python-opencv-affine-transformation/
2. Perspective Transformations : https://www.geeksforgeeks.org/perspective-transformation-python-opencv/
3. Canny Edge Detection : https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_imgproc/py_canny/py_canny.html
4. Smoothing Image : https://docs.opencv.org/master/d4/d13/tutorial_py_filtering.html
5. Detecting Polygon : https://www.geeksforgeeks.org/python-detect-polygons-in-an-image-using-opencv/
6. Convex Hull : https://learnopencv.com/convex-hull-using-opencv-in-python-and-c/